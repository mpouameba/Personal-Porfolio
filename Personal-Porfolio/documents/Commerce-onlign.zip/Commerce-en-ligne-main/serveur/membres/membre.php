<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Etui Papeterie</title>
    <link rel="stylesheet" href="../../client/utilitaires/bootstrap-5.3.0-alpha1-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../client/utilitaires/bootstrap-icons.css">
    <link rel="stylesheet" href="../../client/css/style.css">
    <script src="../../client/utilitaires/jquery-3.6.3.min.js"></script>
    <script src="../../client/utilitaires/bootstrap-5.3.0-alpha1-dist/js/bootstrap.min.js"></script>
    <script src="../../client/js/global.js"></script>
</head>
<body>
<?php require_once('../includes/nav.inc.php'); ?>
<div class="container">
<h1>Bienvenue à la page membre<h1>
</div>

</body>
</html>