# Commerce-en-ligne
**Nom**: Papeterie Laura

**Description**: Projet d’une application multi page de commerce en ligne pour des articles de bureau. 

Communication Client-Serveur avec PHP utilisant un stockage de données par base de données (avec un CRUD).

Partie 1: Devenir Membre et Connexion

Partie 2: Administrateur - gérer le CRUD (Create, Read, Update et Delete) concernant les articles.

Partie 3: Membres - modifier le profil, faire la mise à jour des articles dans le panier.

